from django.apps import AppConfig


class MulticampusModuleprjConfig(AppConfig):
    name = 'multicampus_moduleprj'
